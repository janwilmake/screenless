import { homedir } from "node:os";
import { join } from "node:path";
import { mkdir, readFile, writeFile, rm, chmod } from "node:fs/promises";
const DIR = join(homedir(), ".screenless");
const FILE = join(DIR, "config.json");
export async function load() {
    try {
        return JSON.parse(await readFile(FILE, "utf8"));
    }
    catch {
        return null;
    }
}
export async function save(config) {
    await mkdir(DIR, { recursive: true, mode: 0o700 });
    // Write first, then tighten. A token is a bearer credential; it should never
    // be group- or world-readable, even briefly.
    await writeFile(FILE, JSON.stringify(config, null, 2), { mode: 0o600 });
    await chmod(FILE, 0o600);
    return FILE;
}
export async function clear() {
    await rm(FILE, { force: true });
}
export const configPath = FILE;
//# sourceMappingURL=config.js.map